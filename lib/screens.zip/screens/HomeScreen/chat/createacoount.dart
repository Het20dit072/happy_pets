import 'package:flutter/material.dart';
import 'package:happy_pets/screens/HomeScreen/HomePage.dart';
class createAccount extends StatefulWidget {
 
  createAccount(String _name, String _email, String _password);



  @override
    _createAccountState createState() => _createAccountState();

}

class _createAccountState extends State<createAccount> {
   TextEditingController _name= TextEditingController();
 TextEditingController _email= TextEditingController();
 TextEditingController _password= TextEditingController();
 
bool isloding = false;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body:SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
            height: size.height/50,
            
          ),
          Container(
            alignment: Alignment.centerLeft,
            width: size.width/1.2,
            child:IconButton( 
              onPressed: (){}, icon:Icon (Icons.arrow_back_ios)),
          ),
           SizedBox(
          height: size.height/20
          ,),

          Container(
            width: size.width /1.3,
            child:Text("Welcome",
            style:TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold             ),
              ),
          ),
          Container(
            width: size.width/1.3,
            child:Text("Create Account to continue!",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 20,
              fontWeight: FontWeight.w500,

            ),
            ),
          ),
          SizedBox(
            height: size.height/20,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical:18.0),
          child:Container(
            width: size.width,
            alignment: Alignment.center,
   child: field(size,"Name",Icons.account_box,_name),
          ),
          ),
          Container(
            width: size.width,
            alignment: Alignment.center,
   child: field(size,"email",Icons.account_box,_email),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical:18.0),
            child: Container(
              width: size.width,
              alignment: Alignment.center,
              child: field(size,"password",Icons.lock,_password),
            ),
            ),
            SizedBox(
              height: size.height/20,
            ),
           customButton(size),
           Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
            onTap: () => Navigator.pop(context),
             child: Text("login",
             style:TextStyle(
              color:Colors.blue,
              fontSize:16,
              fontWeight:FontWeight.w500 
              )),
           ),
           ), 
            
            SizedBox(
            height: size.height/40,
           ) , 
           GestureDetector (
            onTap:()=> Navigator.of(context)
             .push(MaterialPageRoute(builder:(_) => createAccount(_name.text,_email.text,_password.text))),
           child: Text(
            "Create Account",
            style: TextStyle(color:Colors.blue,
            fontSize:16,
            fontWeight: FontWeight.w500),
            )
           )  
      ],
          )
      )
    );
  }
  Widget customButton(Size size)
 { return GestureDetector (
  onTap: () { 
     if(_name.text.isNotEmpty &&
     _email.text.isNotEmpty &&
     _password.text.isNotEmpty)
     {
       setState(() {
        
         isloding=true;
       });
       
         
      
     }
     else{
      print("Please enter fields");
     }
    }, 
  child:Container(
      height: size.height/14,
  width: size.width/1.2,
  decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(10),
    color : Colors.blue,
  ),
  alignment: Alignment.center,
  child: Text(
    "Create Account",
    style:TextStyle(
      color:Colors.white,
      fontSize:16,
      fontWeight: FontWeight.bold,
      )
      ),
  )
  );
 }
 Widget field(Size size, String hintText,IconData icon,TextEditingController cont){
  
  return Container(
    height: size.height/14,
    width:size.width/1.1,
    child: TextField(
      controller: cont,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10)
        )
      ),
    ),
  );
 }
}