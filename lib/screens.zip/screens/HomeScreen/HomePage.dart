import 'dart:ui';

import 'package:custom_navigation_bar/custom_navigation_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:happy_pets/screens/HomeScreen/add_pet.dart';
import 'package:happy_pets/screens/HomeScreen/artical.dart';
import 'package:happy_pets/screens/HomeScreen/chat.dart';
import 'package:happy_pets/screens/HomeScreen/home.dart';
import 'package:happy_pets/screens/Login/Login.dart';
import 'package:happy_pets/widgets/pet_cards.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  int selectedCategory = 0;

  var scaffoldKey = GlobalKey<ScaffoldState>();
  static List<Widget> _widgetOptions = <Widget>[Home(), Artical(), chat()];

  void _onItemTapped(index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      body: _widgetOptions.elementAt(_currentIndex),
      floatingActionButton: _buildFloatingBar(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Future _showModel() {
    return showModalBottomSheet(
        context: this.context,
        builder: (context) => Center(
              child: Text("Hello"),
            ));
  }

  Widget _buildFloatingBar() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: CustomNavigationBar(
        blurEffect: true,
        iconSize: 30.0,
        selectedColor: Color(0xFF0C18FB),
        strokeColor: Color(0x300c18fb),
        unSelectedColor: Colors.grey[600],
        backgroundColor: Colors.white,
        borderRadius: Radius.circular(20.0),
        items: [
          CustomNavigationBarItem(
            icon: Icon(Icons.home),
          ),
          CustomNavigationBarItem(
            icon: Icon(Icons.article_outlined),
          ),
          CustomNavigationBarItem(
            icon: GestureDetector(
              onTap: () => showModalBottomSheet(
                
                  shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(20))),
                  backgroundColor: Colors.white,
                  
                  context: this.context,
                  builder: (context) => Column(
                    mainAxisSize: MainAxisSize.min,
                        children: 
                          [
                            SizedBox(
                              height: 40,
                            ),
                            
                            Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: ClipRect(
                                  
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                                    child: Container(
                                      
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black,
                                          width: 2
                                        ),
                                        color: Colors.grey.shade200.withOpacity(0.5),
                                        borderRadius: BorderRadius.circular(20.0)
                                      ),
                                      height: 170,
                                      width: 150,
                                      //  margin:EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                                      //color:data.color,
                                      
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 40,
                                          ),
                                          Icon(
                                            Icons.pets_outlined,
                                            size: 30,
                                            color: Colors.black,
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text("ADOPT PET",
                                              style: TextStyle(
                                                  fontSize: 18, color: Colors.black),
                                              textAlign: TextAlign.center),
                                              SizedBox(
                                                height: 40,
                                              )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: ClipRect(
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black,
                                          width: 2
                                        ),
                                        color: Colors.grey.shade200.withOpacity(0.5),
                                        borderRadius: BorderRadius.circular(20.0)
                                      ),
                                      height: 170,
                                      width: 150,
                                      //  margin:EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                                      //color:data.color,
                                      
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 50,
                                          ),
                                          Icon(
                                            Icons.pets_outlined,
                                            size: 25,
                                            color: Colors.black,
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text("SHELTER PET",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 18, color: Colors.black),
                                              textAlign: TextAlign.center),
                                              SizedBox(
                                                height: 40,
                                              )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                          SizedBox(
                            height: 20,
                          )
                        ],
                      )),
              child: Icon(Icons.add),
            ),
          ),
          CustomNavigationBarItem(
            icon: Icon(Icons.chat_bubble),
          ),
          CustomNavigationBarItem(
            icon: Icon(Icons.person),
          ),
        ],
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        isFloating: true,
      ),
    );
  }
}
