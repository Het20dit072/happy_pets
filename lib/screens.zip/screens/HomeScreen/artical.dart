import 'package:flutter/material.dart';

class Artical extends StatefulWidget {
  const Artical({ Key? key }) : super(key: key);

  @override
  State<Artical> createState() => _ArticalState();
}

class _ArticalState extends State<Artical> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column()
    );
  }
}